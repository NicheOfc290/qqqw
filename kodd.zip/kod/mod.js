 let cp = require('child_process')
let { promisify } = require('util')
console.log('Connected...')
let exec = promisify(cp.exec).bind(cp)
  let o
  try {
  o = exec('python bot.py')
  } catch (e) {
  o = e
 } finally {
let { stdout, stderr } = o
}
