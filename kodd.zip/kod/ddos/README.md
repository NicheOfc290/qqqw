<h1 align="center">ddos - DDoS Attack Script With 36 Plus Methods</h1>

<p align="center">
<a href="#"><img title="Made in India" src="https://img.shields.io/badge/MADE%20IN-INDIA-green?colorA=%23f5690c&colorB=%23035c00&style=for-the-badge"></a>
</p

<em><h5 align="center">(Code Language - Python 3)</h5></em>
<p align="center">
<a href="https://github.com/the-deepnet"><img title="Author" src="https://img.shields.io/badge/Author-DeepNet-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>


<p align="center">Please Don't Hit '.gov' Websites :)</p>

## Features And Method

 * 💣 Layer7
   * <img src="https://image.flaticon.com/icons/png/128/2431/2431664.png" width="16" height="16" alt="get"> GET | GET Flood
   * <img src="https://cdn0.iconfinder.com/data/icons/database-storage-5/60/server__database__fire__burn__safety-512.png" width="16" height="16" alt="post"> POST | POST Flood
   * <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f9/OVH_Logo.svg/1200px-OVH_Logo.svg.png" width="16" height="16" alt="ovh"> OVH | Bypass OVH
   * <img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/cyber-bullying-2557797-2152371.png" width="16" height="16" alt="stress"> STRESS | Send HTTP Packet With High Byte 
   * <img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/cyber-bullying-2546272-2128939.png" width="16" height="16" alt="ostress"> OSTRESS | STRESS Without Proxy
   * <img src="https://image.flaticon.com/icons/png/512/3132/3132142.png" width="16" height="16" alt="dyn"> DYN | A New Method With Random SubDomain
   * <img src="https://cdn2.iconfinder.com/data/icons/poison-and-venom-fill/160/loris2-512.png" width="16" height="16" alt="slow"> SLOW | Slowloris Old Method of DDoS
   * <img src="https://lyrahosting.com/wp-content/uploads/2020/06/ddos-how-work-icon.png" width="16" height="16" alt="head"> HEAD | https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD
   * <img src="https://cdn.iconscout.com/icon/free/png-512/direct-hit-archery-goal-target-mission-33520.png" width="16" height="16" alt="hit"> HIT | POST Without PROXY
   * <img src="https://img.icons8.com/plasticine/2x/null-symbol.png" width="16" height="16" alt="null"> NULL | Null UserAgent and ...
   * <img src="https://i.pinimg.com/originals/03/2e/7d/032e7d0755cd511c753bcb6035d44f68.png" width="16" height="16" alt="cookie"> COOKIE | Random Cookie PHP 'if (isset($_COOKIE))'
   * <img src="https://image.flaticon.com/icons/png/512/3041/3041248.png" width="16" height="16" alt="brust"> BRUST | A Method with more header
   * <img src="https://image.flaticon.com/icons/png/512/2100/2100795.png" width="16" height="16" alt="pps"> PPS |  Only 'GET / HTTP/1.1\r\n\r\n'
   * <img src="https://cdn3.iconfinder.com/data/icons/internet-security-14/48/DDoS_website_webpage_bomb_virus_protection-512.png" width="16" height="16" alt="even"> EVEN | GET Method with more header
   * <img src="https://masbadar.com/wp-content/uploads/2016/02/Logo-Projects-Shield-2.jpg" width="16" height="16" alt="googleshield"> GSB | Google Project Shield Bypass
   * <img src="https://seeklogo.com/images/D/ddos-guard-logo-CFEFCA409C-seeklogo.com.png" width="16" height="16" alt="DDoSGuard"> DGB | DDoS Guard Bypass
   * <img src="https://i.imgur.com/bGL8qfw.png" width="16" height="16" alt="ArvanCloud"> AVB | Arvan Cloud Bypass
   * <img src="https://techcrunch.com/wp-content/uploads/2019/06/J2LlHqT3qJl0bG9Alpgc-1-730x438.png?w=730" width="16" height="16" alt="CloudFlare"> CFB | CloudFlare Bypass
   * <img src="http://iclouddnsbypass.com/wp-content/uploads/2015/02/iCloudDNSBypassServer.ico" width="16" height="16" alt="bypass"> BYPASS |  Bypass Normal AntiDDoS


* 🧨 Layer4: 
  * <img src="https://raw.githubusercontent.com/kgretzky/pwndrop/master/media/pwndrop-logo-512.png" width="16" height="16" alt="tcp"> TCP | TCP Flood Bypass
  * <img src="https://styles.redditmedia.com/t5_2rxmiq/styles/profileIcon_snoob94cdb09-c26c-4c24-bd0c-66238623cc22-headshot.png" width="16" height="16" alt="udp"> UDP | UDP Flood Bypass
  * <img src="https://belgium.devoteam.com/wp-content/uploads/sites/23/2020/06/Icon-accelarate-hyper-automation-with-RPA-300x301.png" width="16" height="16" alt="syn"> SYN | SYN Flood
  * <img src="https://cdn.iconscout.com/icon/free/png-256/virus-2165355-1821015.png" width="16" height="16" alt="vse"> VSE | VSE Flood Only Connection
  * <img src="https://cdn.iconscout.com/icon/free/png-512/redis-4-1175103.png" width="16" height="16" alt="mem"> MEM | Memcached Flood
  * <img src="https://lyrahosting.com/wp-content/uploads/2020/06/ddos-attack-icon.png" width="16" height="16" alt="ntp"> NTP | NTP Flood OLD Method Of Layer4

* 🏹 Layer3
  * <img src="https://image.flaticon.com/icons/png/512/388/388466.png" width="16" height="16" alt="icmp"> ICMP | Flood ICMP Request
  * ⚔️ POD | Ping Of Death OLD Method Of DDoS

* ⚙️ Tools - Run With 'python3 start.py tools'
  * 🌟 CFIP | Find Real IP address of Website Powered by Cloudflare
  * 🔪 DNS | Show Site DNS Records
  * ⚠️ PING | PING server
  * 📌 CHECK | Check Website Die or no
  * 😎 DSTAT | a Method show Receive And Send Bytes Size

* 🎩 Other
  * ❌ STOP | STOP All Attacks
  * 🌠 TOOLS | Tools Console
  * 👑 HELP | Show Usge Script

* Layer4 DDoS Script


#### Like the project? Leave a ? star on the repository!

### Getting Started

**Requirements**

* [Python3][python3]
* requests
* PySocks
* cfscrape
* icmplib
* scapy
---

## Installation :

`git clone https://github.com/the-deepnet/ddos.git`

`cd ddos`

`pip3 install -r requirements.txt`

---

#### > Run :

`python3 ddos`

`python3 ddos bypass https://example.com 5 1000 socks5.txt 100 100`

### <<< If you copy , Then Give me The Credits >>>

## Features :
#### [+] Best DDoS Tool in the market !
#### [+] Based On Proxies !
#### [+] Easy for Beginners !
 
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://github.com/the-deepnet"><img title="Followers" src="https://img.shields.io/github/followers/the-deepnet?color=blue&style=flat-square"></a>
<a href="https://twitter.com/the_deepnet"><img title="Contributer" src="https://img.shields.io/twitter/follow/the_deepnet?label=%40the_deepnet&style=social"></a>
<a href="https://instagram.com/the_deepnet"><img title="Instagram" src="https://img.shields.io/badge/IG-%40DeepNet-red?style=for-the-badge&logo=instagram"></a>
<a href="https://m.me/tdeepnet"><img title="Facebook" src="https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger"></a>
<a href="https://github.com/the-deepnet"><img title="GitHub" src="https://img.shields.io/badge/Github-DeepNet-green?style=for-the-badge&logo=github"></a>
</p>
